/* Sample Single Page Application (SPA)
 * to feature the equipment manager's front-end to approval central
 * used in workshop LAB07
 * (C) 2023 HCL America Inc, All rights reserved
 */

/* Sections of the SPA, one shown at a time */
const spaSections = ['credentials', 'approvalview'];
const insertionPointId = 'approvalview';
const urls = {
  login: '/api/v1/auth',
  list: '/api/v1/query?dataSource=approvals&action=execute',
  decision:
    '/api/v1/document/{{pendingApproval}}?dataSource=approvals&mode=decision'
};

const login = (user, pwd) => {
  fetch(urls.login, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ username: user, password: pwd })
  })
    .then((response) => response.json())
    .then((json) => extractCredentials(json))
    .catch((err) => statusError(err));
};

const extractCredentials = (json) => {
  if (json.bearer) {
    let bearer = json.bearer;
    window.bearer = bearer;
    statusMsg('Login successful');
    toggleSPA('approvalview', 'flex');
    loadApprovals();
  } else {
    statusMsg('Login failed');
  }
};

const loadApprovals = () => {
  document.querySelector('body').style.cursor = 'wait';
  const query = {
    query: "form = 'equipment' and status = 'pending'",
    viewRefresh: true,
    noViews: false
  };
  fetch(urls.list, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${window.bearer}`
    },
    body: JSON.stringify(query)
  })
    .then((response) => response.json())
    .then((json) => displayApprovals(json))
    .catch((err) => statusError(err));
};

const displayApprovals = (json) => {
  const insertionPoint = document.getElementById(insertionPointId);
  while (insertionPoint.hasChildNodes()) {
    insertionPoint.removeChild(insertionPoint.firstChild);
  }
  if (json.length < 1) {
    insertionPoint.innerText = 'No pending approvals, go play golf';
  } else {
    const template = document.getElementById('approval-detail');
    json.forEach((j) => displayOneApproval(insertionPoint, template, j));
  }
  document.querySelector('body').style.cursor = 'default';
};

const displayOneApproval = (insertionPoint, template, json) => {
  const clone = template.content.cloneNode(true);
  Object.keys(json).forEach((k) => {
    const target = clone.getElementById(k);
    if (target) {
      if (typeof json[k] != 'object') {
        target.innerText = json[k];
      } else {
        target.innerText = JSON.stringify(json[k]);
      }
    }
  });
  // Wire actions
  clone.getElementById('approve').addEventListener('click', () => {
    decision(json['@meta'].unid, 'approved', json.CurrentApprover);
  });

  clone.getElementById('reject').addEventListener('click', () => {
    decision(json['@meta'].unid, 'rejected', json.CurrentApprover);
  });
  //Append approval request
  insertionPoint.appendChild(clone);
};

const decision = (unid, what, approver) => {
  const msg = `${unid} ${what} by ${approver}`;
  const realURL = urls.decision.replace('{{pendingApproval}}', unid);
  const payload = { newHistory: what, completedApprover: approver };
  fetch(realURL, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${window.bearer}`
    },
    body: JSON.stringify(payload)
  })
    .then((response) => response.json())
    .then((json) => submissionResult(msg, json))
    .catch((err) => statusError(err));
};

const submissionResult = (msg, json) => {
  if (200 != json.status && !json['@meta']) {
    statusMsg('Failure: ' + json.message + ' for attempted ' + msg);
    return;
  }
  statusMsg(msg);
  loadApprovals();
};

const toggleSPA = (showme, how) => {
  spaSections.forEach((s) => {
    const display = showme === s ? how : 'none';
    document.getElementById(s).style.display = display;
  });
};

const formLogin = () => {
  let username = document.getElementById('username-input').value;
  let password = document.getElementById('password-input').value;
  login(username, password);
};

const statusMsg = (statusText) => {
  document.getElementById('message').innerHTML = statusText;
};

const statusError = (err) => {
  console.error(err);
  document.getElementById('message').innerText = err.message;
  document.style.cursor = 'default';
};

const bootstrap = () => {
  let login_button = document.getElementById('login-btn');
  login_button.addEventListener('click', formLogin);
  toggleSPA('credentials', 'block');
};

if (document.readyState != 'loading') {
  bootstrap();
} else {
  document.addEventListener('DOMContentLoaded', bootstrap);
}
