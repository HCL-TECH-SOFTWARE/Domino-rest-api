# Collabora install

## Setup `.env`

```env
COLLABORA_DOMAIN=office.demo.io:9980
COLLABORA_USER=admin
COLLABORA_PASSWORD=secret
```
