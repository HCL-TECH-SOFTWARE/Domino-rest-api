# Azure IdP Test for KEEP JWT

Simple test to check if a registered App in Azure AD can be used as JWT provider for the Domino REST API

## Requirements

- NodeJS
- Domino REST API
- Azure AD registered app

## Installation

```bash
npm run install
node server.js
```

Navigate to [http://localhost:8080](http://localhost:8080) and fill in the form.
