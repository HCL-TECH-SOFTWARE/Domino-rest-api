const bootstrap = () => {
  const btnSend = document.querySelector('#btnSend');
  btnSend.addEventListener('click', (event) => {
    event.preventDefault();
    loadWellKnown()
      .then(() => {
        const form = document.querySelector('#authForm');
        form.submit();
      })
      .catch((e) => {
        document.querySelector('#msg').textContent = e.message;
        console.error(e);
      });
  });
};

const loadWellKnown = () => {
  const tennant = document.querySelector('#tennant').value;
  const wellK = `https://login.microsoftonline.com/${tennant}/v2.0/.well-known/openid-configuration`;
  return fetch(wellK)
    .then((response) => response.json())
    .then((body) => {
      const sStore = window.sessionStorage;
      sStore.setItem('authorization_endpoint', body.authorization_endpoint);
      sStore.setItem('token_endpoint', body.token_endpoint);
      sStore.setItem('keep', document.querySelector('#keep').value);
      sStore.setItem('client_id', document.querySelector('#ClientId').value);
      sStore.setItem(
        'client_secret',
        document.querySelector('#ClientSecret').value
      );
      sStore.setItem(
        'redirect_uri',
        document.querySelector('#redirectURI').value
      );
      document.querySelector('#authForm').action = body.authorization_endpoint;
      document.querySelector('#msg').textContent = 'loaded...';
    });
};

if (document.readyState != 'loading') {
  bootstrap();
} else {
  document.addEventListener('DOMContentLoaded', bootstrap);
}
