const removeChildren = (parent) => {
  while (parent.lastChild) {
    parent.removeChild(parent.lastChild);
  }
};

const addRow = (parent, key, value) => {
  const row = document.createElement('tr');
  const col1 = document.createElement('td');
  const col2 = document.createElement('td');
  col1.textContent = key;
  col2.textContent = value;
  row.appendChild(col1);
  row.appendChild(col2);
  parent.appendChild(row);
};

const tokenMagic = () => {
  const btnSend = document.querySelector('#btnSend');
  btnSend.style.display = 'none';
  const sStore = window.sessionStorage;
  const token_endpoint = sStore.getItem('token_endpoint');
  const headers = new Headers();
  headers.append('Content-Type', 'application/json');
  const data = {
    token_endpoint: token_endpoint,
    grant_type: 'authorization_code',
    code: sStore.getItem('code'),
    redirect_uri: sStore.getItem('redirect_uri'),
    client_id: sStore.getItem('client_id'),
    client_secret: sStore.getItem('client_secret'),
    session_state: sStore.getItem('session_state'),
    keep: sStore.getItem('keep')
  };
  const options = {
    method: 'POST',
    body: JSON.stringify(data),
    headers: headers,
    redirect: 'follow'
  };
  fetch('/redirect', options)
    .then((response) => {
      if (response.status > 200) {
        throw new Error(response.statusText);
      }
      return response.json();
    })
    .then((json) => {
      const tbody = document.querySelector('#parmbody');
      removeChildren(tbody);
      for (const j of json) {
        addRow(tbody, j.apiName, j.description + ' (' + j.schemaName + ')');
      }
      document.querySelector('#token').textContent = 'Done!'; //.access_token;
    })
    .catch((e) => {
      document.querySelector('#msg').textContent = e.message;
      console.error(e);
    });
};

const bootstrap = () => {
  document.querySelector('#btnSend').addEventListener('click', (event) => {
    event.preventDefault();
    tokenMagic();
  });
  const params = new URL(document.location).searchParams;
  const tbody = document.querySelector('#parmbody');
  removeChildren(tbody);
  for (const [key, value] of params) {
    addRow(tbody, key, value);
    window.sessionStorage.setItem(key, value);
  }
};

if (document.readyState != 'loading') {
  bootstrap();
} else {
  document.addEventListener('DOMContentLoaded', bootstrap);
}
