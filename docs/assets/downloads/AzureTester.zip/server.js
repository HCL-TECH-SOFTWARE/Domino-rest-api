const express = require('express');
const app = express();
const port = 8080;

process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';

const sampleCall = (token, keepURL) => {
  console.log(token);
  const url = keepURL + 'api/v1/scopes';
  const headers = new Headers();
  headers.append('Authorization', 'Bearer ' + token);
  const options = {
    method: 'GET',
    headers: headers,
    rejectUnauthorized: false
  };
  return fetch(url, options)
    .then((response) => response.json())
    .then((j) => {
      console.log(j);
      return j;
    });
};

app.use(express.static('public'));
app.use(express.json());

app.post('/redirect', (req, res) => {
  const body = req.body;
  const msHeaders = new Headers();
  msHeaders.append('Content-Type', 'application/x-www-form-urlencoded');
  const msBody = new URLSearchParams();
  msBody.append('grant_type', body.grant_type);
  msBody.append('code', body.code);
  msBody.append('client_id', body.client_id);
  msBody.append('client_secret', body.client_secret);
  msBody.append('redirect_uri', body.redirect_uri);

  const options = {
    method: 'POST',
    body: msBody,
    headers: msHeaders
  };

  fetch(body.token_endpoint, options)
    .then((response) => {
      if (response.status > 200) {
        throw new Error(response.statusText);
      }
      return response.json();
    })
    .then((j) => sampleCall(j.access_token, body.keep))
    .then((j) => res.json(j))
    .catch((e) => {
      console.error(e);
      res.json({ error: e.message });
    });
});

app.listen(port, () => {
  console.log(`AzureTester listening on port ${port}`);
});
