# Domino REST API & Vite/vue JS

The Demo application requires the Domino REST API and the `ApprovalCentral.nsf` database

## Setup JSON

Create the `setup.json` file in backend. Client_id and client_secret need to be configured in the Domino REST API

```json
{
  "host": "http://localhost:8880",
  "client_id": "[YOUR ID HERE]",
  "client_secret": "[YOUR SECRET HERE]",
  "callbackURL": "http://localhost:3000/callback",
  "urls": {
    "authorizationURL": "/oauth/authorization",
    "tokenURL": "/oauth/token",
    "approvalList": "/api/v1/lists/PendingApprovals?dataSource=approvals&documents=true&count=10",
    "approvalSubmission": "/api/v1/document/{{pendingApproval}}?dataSource=approvals&mode=decision"
  },
  "scope": "approvals"
}
```

## Building the app (minimal approach)

- Run `npm install` in `backend` and `front-end/approval-proj`
- Run `npm run build` copy the generated conten from `dist` into `backend/static`

## Running the app

In `backend` run `node app.js`. It will make the application available on `http://localhost:3000` The root will redirect you to the KEEP access prompt

Navigate to `/approvals` for a list

## Technologies Used

1. Vite + Vue 3 (Composition API) + Tailwind CSS + Typescript
2. ExpressJS
3. PassportJS for OAuth
