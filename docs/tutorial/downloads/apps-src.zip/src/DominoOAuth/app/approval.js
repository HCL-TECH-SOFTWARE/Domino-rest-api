const axios = require('axios');
const setup = require('../setup.json');

// read all
async function getAllApprovals(req, res, next) {
  let target = setup.host + setup.urls.approvalList;
  let result;
  try {
    result = await axios.get(target);
    let data = result.data;
    res.send(data);
    console.log(data);
  } catch (e) {
    if (result.data) {
      res.send(data);
    } else {
      res.send(e.message);
    }
  }
}

async function createApproval(req, res, next) {
  let data = req.body;
  let unid = data.unid;
  let target = setup.host + setup.urls.approvalSubmission;
  const realURL = target.replace('{{pendingApproval}}', unid);
  let result = {};
  try {
    result = await axios.put(realURL, data, {
      headers: {
        'Content-type': 'application/json'
      }
    });
    res.send(result.data);
  } catch (e) {
    console.error(e);
    if (result.data) {
      res.send(result.data);
    } else {
      res.send(e.message);
    }
  }
}

module.exports = {
  getAllApprovals,
  createApproval
};
