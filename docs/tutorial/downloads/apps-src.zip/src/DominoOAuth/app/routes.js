/* (C) 2023 HCL America Inc, Apache 2.0 license */
const express = require('express');
const router = express.Router();
const passport = require('passport');
const { v4: uuidv4 } = require('uuid');
const setup = require('../setup.json');
const ensureAuthenticated = require('./auth').ensureAuthenticated;
const approvalFunctions = require('./approval');

/* All routes are listed here by alphabet*/
/* Static routes go last */

router.get(
  '/approvals',
  ensureAuthenticated,
  approvalFunctions.getAllApprovals
);

router.post(
  '/approvals',
  ensureAuthenticated,
  approvalFunctions.createApproval
);

router.get(
  '/auth/callback',
  passport.authenticate('oauth2', {
    failureRedirect: '/login',
    successRedirect: '/'
  })
);

router.get(
  '/login',
  passport.authenticate('oauth2', {
    scope: setup.scope,
    state: uuidv4()
  })
);

// Don't use a GET for logout, prefetch will kill you
router.get('/logout', (req, res, next) => {
  req.logout((err) => {
    if (err) {
      return next(err);
    }
    res.redirect('/');
  });
});

// Test endpoint only
router.get('/ping', ensureAuthenticated, function (req, res) {
  res.status(200).send('pong!');
});

module.exports = router;
