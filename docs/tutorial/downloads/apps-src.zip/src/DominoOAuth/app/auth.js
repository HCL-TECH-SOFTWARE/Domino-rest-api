const axios = require('axios');

// NOTE: Need to protect all API calls (other than login/logout) with this check
function ensureAuthenticated(req, res, next) {
  console.log('Calling: ensureAuthenticated.....');
  if (req.isAuthenticated()) {
    // accesstoken is available
    if (req.user.accessToken) {
      let AUTH_TOKEN = req.user.accessToken;
      axios.defaults.headers.common['Authorization'] = `Bearer ${AUTH_TOKEN}`;
      console.log('hey token is here');
      res.cookie('jwt', AUTH_TOKEN, { httpOnly: true, maxAge: 3600000 });
    }
    return next();
  } else {
    res.status(401);
    res.send('Nope, no good');
  }
}

module.exports = {
  ensureAuthenticated
};
