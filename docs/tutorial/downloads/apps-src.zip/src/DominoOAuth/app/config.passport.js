const passport = require('passport');
const OAuth2Strategy = require('passport-oauth2').Strategy;
const setup = require('../setup.json');

const host = setup.host;

// open id stuffs

const strategy = new OAuth2Strategy(
  {
    authorizationURL: host + setup.urls.authorizationURL,
    tokenURL: host + setup.urls.tokenURL,
    clientID: setup.client_id,
    clientSecret: setup.client_secret,
    callbackURL: setup.callbackURL
  },

  (accessToken, refreshToken, profile, cb) => {
    // In this example, the user's profile is supplied as the user record.
    // In a production-quality application, the profile should be associated
    // with a user record in the application's database, which allows for
    // account linking and authentication with other identity providers.
    profile.accessToken = accessToken;
    // for refresh
    profile.refreshToken = refreshToken;

    return cb(null, profile);
  }
);

passport.use(strategy);

// Configure Passport authenticated session persistence.
//
// In order to restore authentication state across HTTP requests, Passport needs
// to serialize users into and deserialize users out of the session.  In a
// production-quality application, this would typically be as simple as
// supplying the user ID when serializing, and querying the user record by ID
// from the database when deserializing.  However, due to the fact that this
// example does not have a database, the complete profile is serialized
// and deserialized.
passport.serializeUser(function (user, cb) {
  cb(null, user);
});

passport.deserializeUser(function (obj, cb) {
  cb(null, obj);
});

module.exports = passport;
