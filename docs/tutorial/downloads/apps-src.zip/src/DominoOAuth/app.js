/* (C) 2023 HCL America Inc, Apache 2.0 license */
const express = require('express');
const app = express();

const passport = require('./app/config.passport');
const router = require('./app/routes');
const bodyParser = require('body-parser');
const expressSession = require('express-session');
const cookieParser = require('cookie-parser');
const { v4: uuidv4 } = require('uuid');

// Resetting session secret on each restart
const sessionSecret = uuidv4();
const session = {
  secret: sessionSecret,
  cookie: {
    maxAge: 600000
  },
  resave: false,
  saveUninitialized: false
};

app.use(cookieParser());
app.use(expressSession(session));
app.use(passport.initialize());
app.use(passport.session());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.use('/', router);
// Finally all static pages
const path = __dirname + '/static/';
app.use(express.static(path));
app.listen(3000);
