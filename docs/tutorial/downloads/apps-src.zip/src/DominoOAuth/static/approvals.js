/* Modified sample using 2 pages and oauth
 * (C) 2023 HCL America Inc, All rights reserved
 */
const insertionPointId = 'approvalview';
const urls = {
  list: '/approvals',
  decision: '/approvals'
};

const loadApprovals = () => {
  document.querySelector('body').style.cursor = 'wait';
  fetch(urls.list)
    .then((response) => response.json())
    .then((json) => displayApprovals(json))
    .catch((err) => statusError(err));
};

const displayApprovals = (json) => {
  const insertionPoint = document.getElementById(insertionPointId);
  while (insertionPoint.hasChildNodes()) {
    insertionPoint.removeChild(insertionPoint.firstChild);
  }
  if (json.length < 1) {
    insertionPoint.innerText = 'No pending approvals, go play golf';
  } else {
    const template = document.getElementById('approval-detail');
    json.forEach((j) => displayOneApproval(insertionPoint, template, j));
  }
  document.querySelector('body').style.cursor = 'default';
};

const displayOneApproval = (insertionPoint, template, json) => {
  const clone = template.content.cloneNode(true);
  Object.keys(json).forEach((k) => {
    const target = clone.getElementById(k);
    if (target) {
      if (typeof json[k] != 'object') {
        target.innerText = json[k];
      } else {
        target.innerText = JSON.stringify(json[k]);
      }
    }
  });
  // Wire actions
  clone.getElementById('approve').addEventListener('click', () => {
    decision(json['@meta'].unid, 'approved', json.CurrentApprover);
  });

  clone.getElementById('reject').addEventListener('click', () => {
    decision(json['@meta'].unid, 'rejected', json.CurrentApprover);
  });
  //Append approval request
  insertionPoint.appendChild(clone);
};

const decision = (unid, what, approver) => {
  const msg = `${unid} ${what} by ${approver}`;
  const payload = { newHistory: what, completedApprover: approver, unid: unid };
  fetch(urls.decision, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  })
    .then((response) => response.json())
    .then((json) => submissionResult(msg, json))
    .catch((err) => statusError(err));
};

const submissionResult = (msg, json) => {
  if (200 != json.status && !json['@meta']) {
    statusMsg('Failure: ' + json.message + ' for attempted ' + msg);
    return;
  }
  statusMsg(msg);
  loadApprovals();
};

const statusMsg = (statusText) => {
  document.getElementById('message').innerHTML = statusText;
};

const statusError = (err) => {
  console.error(err);
  document.getElementById('message').innerText = err.message;
  document.style.cursor = 'default';
};

const bootstrap = () => {
  console.log('Boostrap running');
  loadApprovals();
};

if (document.readyState != 'loading') {
  bootstrap();
} else {
  document.addEventListener('DOMContentLoaded', bootstrap);
}
