# Domino REST API - Java ETL Example

This is part of the Engage 2023 workshop

## Scenario

An external system (e.g. HR) deposits a CSV file in a known location that needs to be loaded into Domino for further processing, a typical [ETL](https://en.wikipedia.org/wiki/Extract,_transform,_load) scenario

## How to use

All values are read from `config.json`. There username, password and file name need to exist.
You can run the application using `java -jar etl.jar`. It will read the csv file and generate training request documents and terminate thereafter

## Building from source

You need a Java JDK installed (current version will do) and [Apache Maven](https://maven.apache.org/)

To compile and package the application run:

```java
mvn clean package
```

To run the application directly from source:

```java
mvn clean compile exec:java
```

YMMV
